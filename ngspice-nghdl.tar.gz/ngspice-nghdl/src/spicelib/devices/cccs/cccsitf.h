/**********
Copyright 1990 Regents of the University of California.  All rights reserved.
**********/
#ifndef DEV_CCCS
#define DEV_CCCS

SPICEdev *get_cccs_info(void);

#endif
