/**********
Copyright 2004 Regents of the University of California.  All rights reserved.
Author: 2000 Weidong Liu.
Author: 2001- Xuemei Xi
File: bsim4v5itf.h
**********/

#ifndef DEV_BSIM4V5
#define DEV_BSIM4V5

SPICEdev *get_bsim4v5_info(void);

#endif
