#ifndef _JFET2INIT_H
#define _JFET2INIT_H

extern IFparm JFET2pTable[ ];
extern IFparm JFET2mPTable[ ];
extern char *JFET2names[ ];
extern int JFET2pTSize;
extern int JFET2mPTSize;
extern int JFET2nSize;
extern int JFET2iSize;
extern int JFET2mSize;

#endif
