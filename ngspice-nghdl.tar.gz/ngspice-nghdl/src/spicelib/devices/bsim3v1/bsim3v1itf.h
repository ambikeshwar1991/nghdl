/**********
Copyright 1990 Regents of the University of California.  All rights reserved.
Author: 1991 JianHui Huang and Min-Chie Jeng.
Modified: 2002 Paolo Nenzi.
File: bsim3v1itf.h
**********/

#ifndef DEV_BSIM3v1
#define DEV_BSIM3v1

SPICEdev *get_bsim3v1_info(void);

#endif

