/**********
Copyright 1990 Regents of the University of California.  All rights reserved.
Author: 1991 JianHui Huang and Min-Chie Jeng.
File: bsim3v0itf.h
**********/

#ifndef DEV_bsim3v0
#define DEV_bsim3v0

SPICEdev *get_bsim3v0_info(void);

#endif

