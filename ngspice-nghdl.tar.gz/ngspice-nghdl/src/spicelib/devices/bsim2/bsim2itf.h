/**********
Copyright 1990 Regents of the University of California.  All rights reserved.
**********/
#ifndef DEV_BSIM2
#define DEV_BSIM2

SPICEdev *get_bsim2_info(void);

#endif
