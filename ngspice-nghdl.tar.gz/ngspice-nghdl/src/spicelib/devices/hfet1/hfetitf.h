#ifndef DEV_HFETA
#define DEV_HFETA

SPICEdev *get_hfeta_info(void);

#endif

