#ifndef _HFET2INIT_H
#define _HFET2INIT_H

extern IFparm HFET2pTable[ ];
extern IFparm HFET2mPTable[ ];
extern char *HFET2names[ ];
extern int HFET2pTSize;
extern int HFET2mPTSize;
extern int HFET2nSize;
extern int HFET2iSize;
extern int HFET2mSize;

#endif
