#ifndef _DIOINIT_H
#define _DIOINIT_H

extern IFparm DIOpTable[ ];
extern IFparm DIOmPTable[ ];
extern char *DIOnames[ ];
extern int DIOpTSize;
extern int DIOmPTSize;
extern int DIOnSize;
extern int DIOiSize;
extern int DIOmSize;

#endif
