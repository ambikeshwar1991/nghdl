#ifndef _MOS6INIT_H
#define _MOS6INIT_H

extern IFparm MOS6pTable[ ];
extern IFparm MOS6mPTable[ ];
extern char *MOS6names[ ];
extern int MOS6nSize;
extern int MOS6pTSize;
extern int MOS6mPTSize;
extern int MOS6iSize;
extern int MOS6mSize;

#endif
