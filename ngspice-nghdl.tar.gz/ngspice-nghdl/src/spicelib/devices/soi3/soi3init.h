#ifndef _SOI3INIT_H
#define _SOI3INIT_H

extern IFparm SOI3pTable[ ];
extern IFparm SOI3mPTable[ ];
extern char *SOI3names[ ];
extern int SOI3pTSize;
extern int SOI3mPTSize;
extern int SOI3nSize;
extern int SOI3iSize;
extern int SOI3mSize;

#endif
