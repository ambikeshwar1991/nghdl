/**********
Copyright 1990 Regents of the University of California.  All rights reserved.
**********/
#ifndef DEV_TRA
#define DEV_TRA

SPICEdev *get_tra_info(void);

#endif
