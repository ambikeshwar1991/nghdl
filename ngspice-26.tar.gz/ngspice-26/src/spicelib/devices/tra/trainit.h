#ifndef _TRAINIT_H
#define _TRAINIT_H

extern IFparm TRApTable[ ];
extern char *TRAnames[ ];
extern int TRApTSize;
extern int TRAnSize;
extern int TRAiSize;
extern int TRAmSize;

#endif
