#ifndef _BSIM3INIT_H
#define _BSIM3INIT_H

extern IFparm BSIM3pTable[ ];
extern IFparm BSIM3mPTable[ ];
extern char *BSIM3names[ ];
extern int BSIM3pTSize;
extern int BSIM3mPTSize;
extern int BSIM3nSize;
extern int BSIM3iSize;
extern int BSIM3mSize;

#endif
