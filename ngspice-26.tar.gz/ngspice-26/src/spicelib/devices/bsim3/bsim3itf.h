/**********
Copyright 1999 Regents of the University of California.  All rights reserved.
Author: 1991 JianHui Huang and Min-Chie Jeng.
File: bsim3itf.h
**********/

#ifndef DEV_BSIM3
#define DEV_BSIM3

SPICEdev *get_bsim3_info(void);

#endif
