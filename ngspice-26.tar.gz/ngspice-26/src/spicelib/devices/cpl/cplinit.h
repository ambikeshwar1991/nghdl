#ifndef _CPLINIT_H
#define _CPLINIT_H

extern IFparm CPLpTable[ ];
extern IFparm CPLmPTable[ ];
extern int CPLmPTSize;
extern int CPLpTSize;
extern char *CPLnames[ ];
extern int CPLiSize;
extern int CPLmSize;
extern int CPLnSize;

#endif
