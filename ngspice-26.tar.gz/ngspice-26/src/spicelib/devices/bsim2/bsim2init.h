#ifndef _BSIM2INIT_H
#define _BSIM2INIT_H

extern IFparm B2pTable[ ];
extern IFparm B2mPTable[ ];
extern char *B2names[ ];
extern int B2pTSize;
extern int B2mPTSize;
extern int B2nSize;
extern int B2iSize;
extern int B2mSize;

#endif
