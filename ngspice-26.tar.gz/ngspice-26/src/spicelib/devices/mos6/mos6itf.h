/**********
Copyright 1990 Regents of the University of California.  All rights reserved.
Author: 1989 T. Sakurai
Modified: 1999 Paolo Nenzi
**********/
#ifndef DEV_MOS6
#define DEV_MOS6

SPICEdev *get_mos6_info(void);

#endif
