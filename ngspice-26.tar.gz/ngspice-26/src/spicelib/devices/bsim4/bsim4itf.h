/**********
Copyright 2004 Regents of the University of California.  All rights reserved.
Author: 2000 Weidong Liu.
Author: 2001- Xuemei Xi
File: bsim4itf.h
**********/

#ifndef DEV_BSIM4
#define DEV_BSIM4

SPICEdev *get_bsim4_info(void);

#endif
