#ifndef _HFETAINIT_H
#define _HFETAINIT_H

extern IFparm HFETApTable[ ];
extern IFparm HFETAmPTable[ ];
extern char *HFETAnames[ ];
extern int HFETApTSize;
extern int HFETAmPTSize;
extern int HFETAnSize;
extern int HFETAiSize;
extern int HFETAmSize;

#endif
