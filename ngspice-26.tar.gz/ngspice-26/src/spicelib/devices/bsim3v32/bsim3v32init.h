#ifndef _BSIM3v32INIT_H
#define _BSIM3v32INIT_H

extern IFparm BSIM3v32pTable[ ];
extern IFparm BSIM3v32mPTable[ ];
extern char *BSIM3v32names[ ];
extern int BSIM3v32pTSize;
extern int BSIM3v32mPTSize;
extern int BSIM3v32nSize;
extern int BSIM3v32iSize;
extern int BSIM3v32mSize;

#endif
