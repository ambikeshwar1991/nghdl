#ifndef DEV_HFET2
#define DEV_HFET2

SPICEdev *get_hfet2_info(void);

#endif

