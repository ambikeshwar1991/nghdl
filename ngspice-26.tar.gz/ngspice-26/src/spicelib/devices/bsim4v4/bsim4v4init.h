#ifndef _BSIM4V4INIT_H
#define _BSIM4V4INIT_H

extern IFparm BSIM4v4pTable[ ];
extern IFparm BSIM4v4mPTable[ ];
extern char *BSIM4v4names[ ];
extern int BSIM4v4pTSize;
extern int BSIM4v4mPTSize;
extern int BSIM4v4nSize;
extern int BSIM4v4iSize;
extern int BSIM4v4mSize;

#endif
