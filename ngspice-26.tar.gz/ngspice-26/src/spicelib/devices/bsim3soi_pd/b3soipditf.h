/**********
Copyright 1990 Regents of the University of California.  All rights reserved.
Author: 1998 Samuel Fung
File: b3soipditf.h
**********/
#ifndef DEV_B3SOIPD
#define DEV_B3SOIPD

#include "b3soipdext.h"

SPICEdev *get_b3soipd_info (void);

#endif
