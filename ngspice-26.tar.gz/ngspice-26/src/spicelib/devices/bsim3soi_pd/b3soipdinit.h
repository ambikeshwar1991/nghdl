#ifndef _B3SOIPDINIT_H
#define _B3SOIPDINIT_H

extern IFparm B3SOIPDpTable[];
extern IFparm B3SOIPDmPTable[];
extern char *B3SOIPDnames[];
extern int B3SOIPDpTSize;
extern int B3SOIPDmPTSize;
extern int B3SOIPDnSize;
extern int B3SOIPDiSize;
extern int B3SOIPDmSize;

#endif
