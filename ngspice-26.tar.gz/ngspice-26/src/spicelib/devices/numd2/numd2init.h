#ifndef _NUMD2INIT_H
#define _NUMD2INIT_H

extern IFparm NUMD2pTable[ ];
extern IFparm NUMD2mPTable[ ];
extern char *NUMD2names[ ];
extern int NUMD2pTSize;
extern int NUMD2mPTSize;
extern int NUMD2nSize;
extern int NUMD2iSize;
extern int NUMD2mSize;

#endif
