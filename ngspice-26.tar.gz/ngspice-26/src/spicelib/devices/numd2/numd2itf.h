/**********
Copyright 1991 Regents of the University of California.  All rights reserved.
**********/

#ifndef DEV_NUMD2
#define DEV_NUMD2

extern SPICEdev *get_numd2_info(void);

#endif
