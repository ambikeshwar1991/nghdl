#ifndef _BSIM4V5INIT_H
#define _BSIM4V5INIT_H

extern IFparm BSIM4v5pTable[ ];
extern IFparm BSIM4v5mPTable[ ];
extern char *BSIM4v5names[ ];
extern int BSIM4v5pTSize;
extern int BSIM4v5mPTSize;
extern int BSIM4v5nSize;
extern int BSIM4v5iSize;
extern int BSIM4v5mSize;

#endif
