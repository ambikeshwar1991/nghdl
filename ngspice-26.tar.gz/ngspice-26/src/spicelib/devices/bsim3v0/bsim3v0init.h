#ifndef _BSIM3v0INIT_H
#define _BSIM3v0INIT_H

extern IFparm BSIM3v0pTable[ ];
extern IFparm BSIM3v0mPTable[ ];
extern char *BSIM3v0names[ ];
extern int BSIM3v0pTSize;
extern int BSIM3v0mPTSize;
extern int BSIM3v0nSize;
extern int BSIM3v0iSize;
extern int BSIM3v0mSize;

#endif
